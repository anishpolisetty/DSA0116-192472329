#include <iostream>
#include <iomanip>
using namespace std;
int main() {
    const long long farePaise = 1001; // Rs 10.01
    for (long long n : {20000LL, 500000LL, 3000000LL}) {
        long long exactPaise = farePaise * n;
        double rupees = 10.01 * static_cast<double>(n);
        cout << n << " journeys: integer paise=" << exactPaise
             << ", double rupees=" << setprecision(15) << rupees << '\n';
    }
}
