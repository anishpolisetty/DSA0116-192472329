#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include <utility>
#include <stdexcept>

class Vehicle {
protected:
    std::string reg_;
    double daily_;
    bool rented_=false;
public:
    Vehicle(std::string r,double d):reg_(std::move(r)),daily_(d) {
        if(reg_.empty()||d<0) throw std::invalid_argument("Invalid vehicle");
    }
    virtual ~Vehicle()=default;
    bool rent(){if(rented_)return false;rented_=true;return true;}
    void returnVehicle(){rented_=false;}
    bool isRented()const{return rented_;}
    virtual double rentalCharge(int days)const=0;
    virtual std::string description()const=0;
    double lateFee(int lateDays)const {
        return lateDays>0 ? lateDays*daily_*0.25 : 0.0;
    }
    double totalCharge(int days,int lateDays)const {
        return rentalCharge(days)+lateFee(lateDays);
    }
};
class Bicycle:public Vehicle {
public:
    using Vehicle::Vehicle;
    double rentalCharge(int d)const override{return daily_*d;}
    std::string description()const override{return "Bicycle "+reg_;}
};
class MotorVehicle:public Vehicle {
protected:
    double energy_;
    std::string serviceDate_;
public:
    MotorVehicle(std::string r,double d,double e,std::string date)
      :Vehicle(std::move(r),d),energy_(e),serviceDate_(std::move(date)){}
};
class TwoWheeler:public MotorVehicle {
public:
    using MotorVehicle::MotorVehicle;
    double rentalCharge(int d)const override{return daily_*d;}
    std::string description()const override{return "TwoWheeler "+reg_;}
};
class Car:public MotorVehicle {
protected:int seats_;
public:
    Car(std::string r,double d,double e,std::string date,int s)
      :MotorVehicle(std::move(r),d,e,std::move(date)),seats_(s){}
    double rentalCharge(int days)const override{return daily_*days;}
    std::string description()const override{return "Car "+reg_;}
};
class ElectricCar:public Car {
protected:double battery_,kwhRate_;
public:
    ElectricCar(std::string r,double d,double e,std::string date,
                int seats,double battery,double rate)
      :Car(std::move(r),d,e,std::move(date),seats),
       battery_(battery),kwhRate_(rate){}
    double rentalCharge(int days)const override{
        return daily_*days+battery_*kwhRate_;
    }
    std::string description()const override{return "ElectricCar "+reg_;}
};
class ElectricBus:public ElectricCar {
public:
    using ElectricCar::ElectricCar;
    double rentalCharge(int days)const override{
        return daily_*days+battery_*kwhRate_;
    }
    std::string description()const override{return "ElectricBus "+reg_;}
};
class Fleet {
    std::vector<std::unique_ptr<Vehicle>> items_;
public:
    template<class T,class... A> void add(A&&... a){
        items_.push_back(std::make_unique<T>(std::forward<A>(a)...));
    }
    void list()const{
        for(const auto& v:items_)
            std::cout<<v->description()
                     <<(v->isRented()?" [Rented]":" [Available]")<<'\n';
    }
    void rentAll(){
        for(const auto& v:items_)
            if(v->rent())std::cout<<"Rented "<<v->description()<<'\n';
    }
    void returnAll(int days,int lateDays){
        for(const auto& v:items_)if(v->isRented()){
            std::cout<<v->description()<<" charge "
                     <<v->totalCharge(days,lateDays)<<'\n';
            v->returnVehicle();
        }
    }
};
int main(){
    Fleet f;
    f.add<Bicycle>("B-101",100);
    f.add<TwoWheeler>("T-202",250,70,"2027-02-01");
    f.add<Car>("C-303",1200,50,"2027-03-01",5);
    f.add<ElectricCar>("E-404",1500,80,"2027-04-01",5,60,8);
    // Extension: add ElectricBus without changing Fleet.
    f.add<ElectricBus>("EB-505",3000,90,"2027-05-01",30,250,7);
    f.list(); f.rentAll(); f.returnAll(2,1); f.list();
}
