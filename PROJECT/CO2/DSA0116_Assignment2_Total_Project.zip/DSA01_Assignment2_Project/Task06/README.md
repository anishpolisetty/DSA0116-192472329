# Task06

Implements friend functions for time comparison and minute difference. Benchmark is included to compare inline and noinline calls at -O0 and -O2.

Compile: `g++ -std=c++17 -Wall -Wextra main.cpp -o program`

Run the executable and compare its output with `sample_output.txt`.
