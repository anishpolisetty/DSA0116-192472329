#include <iostream>
#include <stdexcept>
#include <string>
class BillingError : public std::runtime_error { public: using std::runtime_error::runtime_error; };
class InvalidCharge : public BillingError { public: using BillingError::BillingError; };
class ClaimError : public BillingError { public: using BillingError::BillingError; };
class UnknownPackage : public BillingError { public: using BillingError::BillingError; };
class PatientNotFound : public BillingError { public: using BillingError::BillingError; };

void logNoThrow(const std::string& msg) noexcept {
    try { std::cerr << "[LOG] " << msg << '\n'; } catch (...) {}
}
double validateCharge(double amount) {
    if (amount < 0) throw InvalidCharge("charge cannot be negative");
    return amount;
}
int main() {
    try {
        std::cout << "Validated charge: " << validateCharge(2500) << '\n';
        (void)validateCharge(-10);
    } catch (const BillingError& e) {
        logNoThrow(e.what());
        std::cout << "Billing error: " << e.what() << '\n';
    }
}
