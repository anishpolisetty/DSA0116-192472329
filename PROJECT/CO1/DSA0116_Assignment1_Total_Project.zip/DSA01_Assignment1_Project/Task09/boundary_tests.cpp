#include <iostream>
#include <array>
using namespace std;
bool isPeak(int h, int m) {
    if (h < 0 || h > 23 || m < 0 || m > 59) return false;
    return (h >= 8 && h < 10) || (h >= 17 && h < 20);
}
int main() {
    const array<pair<int,bool>,4> tests{{
        {8*60, true}, {10*60, false}, {17*60, true}, {20*60, false}
    }};
    for (auto [minutes, expected] : tests) {
        int h = minutes / 60, m = minutes % 60;
        bool actual = isPeak(h,m);
        cout << h << ':' << (m < 10 ? "0" : "") << m
             << " expected=" << expected << " actual=" << actual
             << (actual == expected ? " PASS" : " FAIL") << '\n';
    }
}
