# Task01

Demonstrates call by value (caller unchanged), call by reference and pointer (caller updated), returning a computed fee, the supplied change/bigger/show output-prediction exercise, and default arguments.

Compile: `g++ -std=c++17 -Wall -Wextra main.cpp -o program`

Run the executable and compare its output with `sample_output.txt`.
