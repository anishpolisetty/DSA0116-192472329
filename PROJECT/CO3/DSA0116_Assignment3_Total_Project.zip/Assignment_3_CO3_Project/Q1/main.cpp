#include <iostream>
#include <stdexcept>
#include <string>
 
class Book {
    std::string title_;
    std::string author_;
    int copies_;
 
    static int checkedCopies(int n) {
        if (n < 0) throw std::invalid_argument("Copies cannot be negative");
        return n;
    }
 
public:
    Book() : Book("", "", 0) {}
 
    explicit Book(const std::string& title)
        : Book(title, "Unknown", 1) {}
 
    Book(const std::string& title, const std::string& author, int copies)
        : title_(title), author_(author), copies_(checkedCopies(copies)) {}
 
    void print() const {
        std::cout << "Title: " << (title_.empty() ? "(empty)" : title_)
                  << ", Author: " << (author_.empty() ? "(empty)" : author_)
                  << ", Copies: " << copies_ << '\n';
    }
};
 
int main() {
    Book empty;
    Book donated("C++ Primer");
    Book full("Clean Code", "Robert C. Martin", 5);
 
    empty.print();
    donated.print();
    full.print();
 
    try {
        Book invalid("Bad Record", "Unknown", -2);
    } catch (const std::invalid_argument& e) {
        std::cout << "Rejected: " << e.what() << '\n';
    }
}
