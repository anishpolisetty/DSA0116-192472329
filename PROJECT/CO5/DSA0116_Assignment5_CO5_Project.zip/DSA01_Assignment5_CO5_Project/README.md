# DSA01 – Assignment 5 (CO5)
## Reliable Software with Runtime Polymorphism and Exceptions

Student name: <Your Name>  
Register number: <Your Register Number>  
Compiler: Record `g++ --version`  
Repository: `DSA01-<RegisterNumber>-Assignment5`

Compile a task:
```bash
g++ -std=c++17 -Wall -Wextra -pedantic Task01/bill_hierarchy.cpp -o task01
./task01
```
Windows: run the generated `.exe`.

| Folder | Contents |
|---|---|
| Task01 | Bill hierarchy and payer policies |
| Task02 | Runtime binding and virtual destructor experiments |
| Task03 | Payer interface and corporate extension |
| Task04 | Exception hierarchy |
| Task05 | Stack unwinding and RAII |
| Task06 | Completed B1 TODO program |
| Task07 | Error conditions and completed ClaimError TODO |
| Task08 | Dispatch and exception benchmarks |
| Task09 | New bill type and new payer |

Run `./build_all.sh` (Linux/macOS) or `build_all.bat` (Windows) to compile and run the safe examples. Task08 benchmarks are run separately. The deliberately unsafe destructor example is excluded from the normal build.

AddressSanitizer example:
```bash
g++ -std=c++17 -Wall -Wextra -pedantic -g -O1 -fsanitize=address -fno-omit-frame-pointer Task02/non_virtual_destructor_unsafe.cpp -o destructor_unsafe
./destructor_unsafe
```
This source deliberately demonstrates undefined behaviour. The exact sanitizer result is compiler/runtime dependent.

Benchmark:
```bash
g++ -std=c++17 -O2 -Wall -Wextra -pedantic Task08/benchmark_dispatch.cpp -o benchmark
./benchmark
```

The benchmark prints measurements from the machine where it runs. Do not copy invented timings. Add actual screenshots, compiler details, sanitizer logs and measured results. Commit progressively, at least one meaningful commit per task. Replace placeholders and add your working GitHub URL to the report.
