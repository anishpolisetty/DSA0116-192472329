# Task07

Diagnoses O(k) shifting per insertion in the fixed-size history and redesigns it as a circular buffer with O(1) insertion. Benchmark both versions on identical operation counts.

Compile: `g++ -std=c++17 -Wall -Wextra main.cpp -o program`

Run the executable and compare its output with `sample_output.txt`.
