#include <cmath>
#include <iomanip>
#include <iostream>
#include <stdexcept>
 
class Complex {
    double re_, im_;
    static constexpr double EPS = 1e-12;
 
public:
    Complex() : re_(0.0), im_(0.0) {}
    Complex(double real) : re_(real), im_(0.0) {}
    Complex(double real, double imag) : re_(real), im_(imag) {}
 
    double real() const { return re_; }
    double imag() const { return im_; }
    double magnitude() const { return std::hypot(re_, im_); }
 
    Complex operator+(const Complex& z) const {
        return {re_ + z.re_, im_ + z.im_};
    }
    Complex operator-(const Complex& z) const {
        return {re_ - z.re_, im_ - z.im_};
    }
    Complex operator*(const Complex& z) const {
        return {re_ * z.re_ - im_ * z.im_,
                re_ * z.im_ + im_ * z.re_};
    }
    Complex operator/(const Complex& z) const {
        double d = z.re_ * z.re_ + z.im_ * z.im_;
        if (d < EPS * EPS) throw std::domain_error("Division by zero impedance");
        return {(re_ * z.re_ + im_ * z.im_) / d,
                (im_ * z.re_ - re_ * z.im_) / d};
    }
    bool operator==(const Complex& z) const {
        return std::abs(re_ - z.re_) < EPS &&
               std::abs(im_ - z.im_) < EPS;
    }
 
    friend std::ostream& operator<<(std::ostream& out, const Complex& z) {
        out << std::fixed << std::setprecision(3)
            << z.re_ << (z.im_ < 0 ? " - j" : " + j")
            << std::abs(z.im_);
        return out;
    }
};
 
int main() {
    const double R = 10.0;
    const double omega = 100.0;
    const double L = 0.1;
    const double C = 0.001;
 
    Complex Zr(R, 0.0);
    Complex Zl(0.0, omega * L);
    Complex Zc(0.0, -1.0 / (omega * C));
 
    Complex series = Zr + Zl + Zc;
    Complex parallel = (Zr * Zl) / (Zr + Zl);
 
    std::cout << "Resistor: " << Zr << '\n';
    std::cout << "Inductor: " << Zl << '\n';
    std::cout << "Capacitor: " << Zc << '\n';
    std::cout << "Series RLC: " << series
              << ", magnitude=" << series.magnitude() << '\n';
    std::cout << "Parallel R-L: " << parallel
              << ", magnitude=" << parallel.magnitude() << '\n';
 
    try {
        Complex zero;
        Complex invalid = Zr / zero;
        std::cout << invalid << '\n';
    } catch (const std::domain_error& e) {
        std::cout << "Error: " << e.what() << '\n';
    }
}
