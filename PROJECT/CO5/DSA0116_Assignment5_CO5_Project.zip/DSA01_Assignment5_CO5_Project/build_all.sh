#!/usr/bin/env bash
set -e
mkdir -p build
run(){ src="$1"; name="$2"; echo "===== $name ====="; g++ -std=c++17 -Wall -Wextra -pedantic "$src" -o "build/$name"; "build/$name"; }
run Task01/bill_hierarchy.cpp task01
run Task02/runtime_binding.cpp task02
run Task03/payer_extension.cpp task03
run Task04/exception_hierarchy.cpp task04
run Task05/stack_unwinding.cpp task05
run Task06/complete_bill_todo.cpp task06
run Task07/claim_rethrow_todo.cpp task07_claim
run Task07/error_conditions.cpp task07_errors
run Task09/extension_test.cpp task09
echo "Safe examples compiled and executed. Run Task08 benchmarks separately."
