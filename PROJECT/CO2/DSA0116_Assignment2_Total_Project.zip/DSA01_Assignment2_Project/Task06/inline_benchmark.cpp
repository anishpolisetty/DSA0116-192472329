#include <iostream>
#include <chrono>
using namespace std;
using namespace chrono;

inline int fastAdd(int a, int b) { return a + b; }
#if defined(__GNUC__)
__attribute__((noinline))
#endif
int ordinaryAdd(int a, int b) { return a + b; }

int main() {
    volatile long long sink = 0;
    const int repetitions = 10000000;
    auto start1 = steady_clock::now();
    for (int i = 0; i < repetitions; ++i) sink += fastAdd(i, 3);
    auto end1 = steady_clock::now();
    auto start2 = steady_clock::now();
    for (int i = 0; i < repetitions; ++i) sink += ordinaryAdd(i, 3);
    auto end2 = steady_clock::now();
    cout << "inline_ms="
         << duration<double, milli>(end1 - start1).count() << '\n';
    cout << "ordinary_ms="
         << duration<double, milli>(end2 - start2).count() << '\n';
    cout << "sink=" << sink << '\n';
}
