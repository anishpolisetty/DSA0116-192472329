#include <iostream>
using namespace std;

struct Parcel {
    double weightKg;
    bool express;
    bool insured;
};

double charge(double weightKg, bool express = false, bool insured = false) {
    double total = weightKg * 20.0;
    if (express) total += 50.0;
    if (insured) total += 15.0;
    return total;
}
double charge(int weightGrams) {
    return charge(weightGrams / 1000.0, false, false);
}
double charge(const Parcel& p) {
    return charge(p.weightKg, p.express, p.insured);
}

int main() {
    cout << "charge(2) = " << charge(2) << " [int grams overload]\n";
    cout << "charge(2.0f) = " << charge(2.0f) << " [double kg overload]\n";
    cout << "charge(2.0) = " << charge(2.0) << " [double kg overload]\n";
    cout << "charge(500) = " << charge(500) << " [int grams overload]\n";
    cout << "charge(2.0, true) = " << charge(2.0, true) << " [default insured=false]\n";
    Parcel p{3.0, true, true};
    cout << "charge(Parcel) = " << charge(p) << " [Parcel overload]\n";
}
