# Task 2: Tokens, keywords, identifiers, constants and enum class

Refer to `../Assignment_Report.docx` for the task explanation and reference answer. The integrated implementation is in `../src/metro_fare_system.cpp`.

## Evidence to add
- Your own source file or a clearly identified relevant excerpt.
- Compile command and compiler version.
- Input/output screenshot from your own execution.
- Short explanation of the result and Big-O complexity where requested.
