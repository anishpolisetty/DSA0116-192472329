#include <cstring>
#include <iostream>
#include <utility>
#include <string>
 
class Text {
    char* data_;
public:
    Text(const char* s = "") {
        std::size_t n = std::strlen(s);
        data_ = new char[n + 1];
        std::memcpy(data_, s, n + 1);
    }
 
    Text(const Text& other) {
        std::size_t n = std::strlen(other.data_);
        data_ = new char[n + 1];
        std::memcpy(data_, other.data_, n + 1);
    }
 
    Text& operator=(const Text& other) {
        if (this == &other) return *this;
        std::size_t n = std::strlen(other.data_);
        char* fresh = new char[n + 1];
        std::memcpy(fresh, other.data_, n + 1);
        delete[] data_;
        data_ = fresh;
        return *this;
    }
 
    ~Text() { delete[] data_; }
 
    Text operator+(const Text& rhs) const {
        std::size_t a = std::strlen(data_);
        std::size_t b = std::strlen(rhs.data_);
        char* buffer = new char[a + b + 1];
        std::memcpy(buffer, data_, a);
        std::memcpy(buffer + a, rhs.data_, b + 1);
        Text result(buffer);
        delete[] buffer;
        return result;
    }
 
    bool operator==(const Text& rhs) const {
        return std::strcmp(data_, rhs.data_) == 0;
    }
    bool operator!=(const Text& rhs) const { return !(*this == rhs); }
 
    friend std::ostream& operator<<(std::ostream& out, const Text& t) {
        return out << t.data_;
    }
};
 
int main() {
    Text a("Hello "), b("C++"), c(" World");
    Text message = a + b + c;
    std::cout << message << '\n';
    message = message; // self-assignment test
    std::cout << std::boolalpha << (message != Text("")) << '\n';
    Text empty("");
    std::cout << "Empty: [" << empty << "]\n";
}
