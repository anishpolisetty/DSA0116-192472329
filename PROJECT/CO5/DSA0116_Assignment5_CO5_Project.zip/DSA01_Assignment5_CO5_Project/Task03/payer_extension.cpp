#include <algorithm>
#include <iostream>
#include <stdexcept>
class Bill {
public: virtual ~Bill()=default; virtual double total() const=0;
};
class SampleBill : public Bill {
    double amount;
public:
    explicit SampleBill(double a):amount(a){if(a<0)throw std::invalid_argument("negative bill");}
    double total() const override{return amount;}
};
class Payer { public: virtual ~Payer()=default; virtual double amountCovered(const Bill&) const=0; };
class SelfPay : public Payer {
public: double amountCovered(const Bill& b) const override{return b.total();}
};
class Insurance : public Payer {
    double limit,copay;
public:
    Insurance(double l,double c):limit(l),copay(c){if(l<0||c<0||c>100)throw std::invalid_argument("invalid policy");}
    double amountCovered(const Bill& b) const override{return std::min(b.total(),limit)*(1-copay/100);}
};
class GovernmentScheme : public Payer {
    double cap;
public: explicit GovernmentScheme(double c):cap(c){}
    double amountCovered(const Bill& b) const override{return std::min(b.total(),cap);}
};
// Additive extension: existing payer classes are not modified.
class CorporatePayer : public Payer {
    double fraction;
public:
    explicit CorporatePayer(double f):fraction(f){if(f<0||f>1)throw std::invalid_argument("fraction must be 0..1");}
    double amountCovered(const Bill& b) const override{return b.total()*fraction;}
};
int main(){
    SampleBill bill(10000); SelfPay s; Insurance i(8000,10);
    GovernmentScheme g(6000); CorporatePayer c(0.75);
    std::cout<<"SelfPay: "<<s.amountCovered(bill)<<'\n'
             <<"Insurance: "<<i.amountCovered(bill)<<'\n'
             <<"Government: "<<g.amountCovered(bill)<<'\n'
             <<"Corporate: "<<c.amountCovered(bill)<<'\n';
}
