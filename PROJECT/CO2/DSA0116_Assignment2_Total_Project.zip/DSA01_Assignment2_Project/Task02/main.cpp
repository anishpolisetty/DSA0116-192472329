#include <iostream>
using namespace std;

int& highestMark(int marks[], int n) {
    int best = 0;
    for (int i = 1; i < n; ++i)
        if (marks[i] > marks[best]) best = i;
    return marks[best];
}
const int& highestMarkReadOnly(const int marks[], int n) {
    int best = 0;
    for (int i = 1; i < n; ++i)
        if (marks[i] > marks[best]) best = i;
    return marks[best];
}
int highestMarkCopy(const int marks[], int n) {
    int best = 0;
    for (int i = 1; i < n; ++i)
        if (marks[i] > marks[best]) best = i;
    return marks[best];
}
// Deliberately unsafe example for explanation only; never call this function.
int& danglingReference() {
    int local = 50;
    return local; // Returning reference to a local variable: undefined behaviour if used.
}

int main() {
    int marks[] = {78, 92, 85, 88};
    int n = sizeof(marks) / sizeof(marks[0]);
    cout << "Highest before moderation: " << highestMark(marks, n) << '\n';
    highestMark(marks, n) += 2;
    cout << "Highest after moderation: " << highestMark(marks, n) << '\n';
    cout << "Read-only highest: " << highestMarkReadOnly(marks, n) << '\n';
    cout << "Returned copy: " << highestMarkCopy(marks, n) << '\n';
}
