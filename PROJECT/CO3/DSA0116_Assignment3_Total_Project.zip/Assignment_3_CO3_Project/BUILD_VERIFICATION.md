# Build verification

Each program was compiled with `g++ -std=c++17 -Wall -Wextra -pedantic` where the compiler was available.

## Q1: PASS

```text
Title: (empty), Author: (empty), Copies: 0
Title: C++ Primer, Author: Unknown, Copies: 1
Title: Clean Code, Author: Robert C. Martin, Copies: 5
Rejected: Copies cannot be negative
```

## Q2: PASS

```text
Ibuprofen ORS | Paracetamol Cetirizine | Paracetamol ORS
```

## Q3: PASS

```text
Event created: 2 x 3
O O O 
O O X 
Event created: 1 x 2
Event closed. Booked seats at closing: 1
Event created: 1 x 2
Event closed. Booked seats at closing: 1
Event closed. Booked seats at closing: 0
Event closed. Booked seats at closing: 1
```

## Q4: PASS

```text
Rs 200.00
true
Rs 1.25
```

## Q5: PASS

```text
0:00:10 0:00:12 0:00:12
Track One
Playlist index out of range
```

## Q6: PASS

```text
Hello C++ World
true
Empty: []
```

## Q7: PASS

```text
Resistor: 10.000 + j0.000
Inductor: 0.000 + j10.000
Capacitor: 0.000 - j10.000
Series RLC: 10.000 + j0.000, magnitude=10.000
Parallel R-L: 5.000 + j5.000, magnitude=7.071
Error: Division by zero impedance
```
