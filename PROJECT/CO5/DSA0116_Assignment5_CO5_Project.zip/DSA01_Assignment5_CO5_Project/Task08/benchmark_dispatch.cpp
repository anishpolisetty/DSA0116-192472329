#include <chrono>
#include <iomanip>
#include <iostream>
#include <variant>
#include <vector>
struct OP{double c,t;double total()const{return c+t;}};
struct IP{double d,r,p,m;double total()const{return d*r+p+m;}};
struct DC{double p;double total()const{return p;}};
struct EM{double b,r,u;double total()const{return b+r*u;}};
using VBill=std::variant<OP,IP,DC,EM>;
struct Record{int type;double a,b,c,d;};
double switchTotal(const Record& x){
    switch(x.type){case 0:return x.a+x.b;case 1:return x.a*x.b+x.c+x.d;
    case 2:return x.a;case 3:return x.a+x.b*x.c;default:return 0;}
}
double variantTotal(const VBill& v){return std::visit([](const auto& x){return x.total();},v);}
template<class F> double timed(F fn){
    volatile double checksum=0;
    auto start=std::chrono::steady_clock::now(); checksum=fn();
    auto stop=std::chrono::steady_clock::now(); (void)checksum;
    return std::chrono::duration<double,std::milli>(stop-start).count();
}
int main(){
    for(std::size_t n:{1000u,1000000u,10000000u}){
        std::vector<Record> records;std::vector<VBill> variants;
        records.reserve(n);variants.reserve(n);
        for(std::size_t i=0;i<n;++i){
            switch(i%4){
            case 0:records.push_back({0,500,1200,0,0});variants.emplace_back(OP{500,1200});break;
            case 1:records.push_back({1,3,2500,40000,0});variants.emplace_back(IP{3,2500,40000,0});break;
            case 2:records.push_back({2,30000,0,0,0});variants.emplace_back(DC{30000});break;
            default:records.push_back({3,2000,500,10,0});variants.emplace_back(EM{2000,500,10});break;
            }
        }
        std::cout<<"Bills "<<n<<'\n';
        std::cout<<"switch checksum/time(ms): ";
        auto sw=timed([&]{double s=0;for(const auto& x:records)s+=switchTotal(x);return s;});
        std::cout<<sw<<'\n';
        std::cout<<"variant checksum/time(ms): ";
        auto vt=timed([&]{double s=0;for(const auto& x:variants)s+=variantTotal(x);return s;});
        std::cout<<vt<<'\n';
    }
}
