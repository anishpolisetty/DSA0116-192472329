# DSA01 – Assignment 1 (CO1): Namma Metro Smart-Card Fare System

## Project contents
- `Assignment_Report.docx` – the supplied CO1 reference-solution document, included as the report/reference.
- `src/metro_fare_system.cpp` – integrated C++17 implementation.
- `Task01` … `Task12` – task-wise folders with source/evidence guidance.
- `README.md` – build and run instructions.

## Requirements and stated assumptions
- Money is stored as integer paise (`long long`) to avoid floating-point currency errors.
- Original zones: Inner ₹10, Middle ₹20, Outer ₹30. Design-challenge zone: Airport ₹60.
- Peak periods: 08:00–09:59 and 17:00–19:59. Therefore 10:00 and 20:00 are off-peak.
- At least ₹50 must remain after a stored-value journey.
- Student/senior concession is assumed to be 50% of base fare, applied before peak surcharge.
- For the design challenge, a 10% weekend discount replaces the peak surcharge; the two do not combine.
- Monthly pass covers two selected zones. Pass validity dates and fare/pass interactions are not specified in the assignment, so this sample demonstrates zone coverage only.

## Compile and run
Using g++ 13.3.0 or a compatible C++17 compiler:

```bash
g++ -std=c++17 -Wall -Wextra -pedantic src/metro_fare_system.cpp -o metro_fare_system
./metro_fare_system
```

On Windows PowerShell:

```powershell
g++ -std=c++17 -Wall -Wextra -pedantic src/metro_fare_system.cpp -o metro_fare_system.exe
.\metro_fare_system.exe
```

## GitHub submission
1. Rename the repository to `DSA01-<RegisterNumber>-Assignment1`.
2. Add your name, register number, faculty details and GitHub URL to the report.
3. Run the program on your own machine and save terminal screenshots in the corresponding task folders.
4. Replace any machine-dependent timings, `sizeof` values, compiler warnings and benchmark results with your own measurements.
5. Commit progressively, with at least one commit per task.

## Important
The assignment asks for individual execution and evidence. The included implementation is a working project starter; verify every task program and add your own screenshots/results before submission.
