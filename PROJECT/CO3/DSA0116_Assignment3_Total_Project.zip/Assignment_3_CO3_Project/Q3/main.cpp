#include <iostream>
#include <stdexcept>
#include <string>
 
class Event {
    int rows_, seats_;
    char** map_;
    int booked_ = 0;
 
public:
    Event(int rows, int seats) : rows_(rows), seats_(seats), map_(nullptr) {
        if (rows < 0 || seats < 0)
            throw std::invalid_argument("Dimensions cannot be negative");
        if (rows_ == 0 || seats_ == 0) return;
 
        map_ = new char*[rows_]{};
        try {
            for (int r = 0; r < rows_; ++r) {
                map_[r] = new char[seats_];
                for (int s = 0; s < seats_; ++s) map_[r][s] = 'O';
            }
        } catch (...) {
            for (int r = 0; r < rows_; ++r) delete[] map_[r];
            delete[] map_;
            map_ = nullptr;
            throw;
        }
        std::cout << "Event created: " << rows_ << " x " << seats_ << '\n';
    }
 
    bool book(int r, int s) {
        if (!map_ || r < 0 || r >= rows_ || s < 0 || s >= seats_) return false;
        if (map_[r][s] == 'X') return false;
        map_[r][s] = 'X'; ++booked_; return true;
    }
 
    bool cancel(int r, int s) {
        if (!map_ || r < 0 || r >= rows_ || s < 0 || s >= seats_) return false;
        if (map_[r][s] == 'O') return false;
        map_[r][s] = 'O'; --booked_; return true;
    }
 
    void print() const {
        for (int r = 0; r < rows_; ++r) {
            for (int s = 0; s < seats_; ++s) std::cout << map_[r][s] << ' ';
            std::cout << '\n';
        }
    }
 
    Event(const Event&) = delete;
    Event& operator=(const Event&) = delete;

    ~Event() {
        if (map_) {
            for (int r = 0; r < rows_; ++r) delete[] map_[r];
            delete[] map_;
        }
        std::cout << "Event closed. Booked seats at closing: " << booked_ << '\n';
    }
};
 
int main() {
    Event local(2, 3);
    local.book(0, 1);
    local.book(1, 2);
    local.cancel(0, 1);
    local.print();
 
    {
        Event blockEvent(1, 2);
        blockEvent.book(0, 0);
    } // blockEvent destructor runs here
 
    Event* heapEvent = new Event(1, 2);
    heapEvent->book(0, 1);
    delete heapEvent; // destructor runs here
 
    Event emptyEvent(0, 5);
}
