# Assignment 3 – CO3: Complete C++ Project

This folder contains the seven standalone C++ programs and the answer document.

## Project structure

| Folder/file | Contents |
|---|---|
| `Q1/main.cpp` | Constructor overloading, delegation and `explicit` |
| `Q2/main.cpp` | Deep copy, copy constructor, assignment and Rule of Three |
| `Q3/main.cpp` | Dynamic event seat map, destructor and object lifetime |
| `Q4/main.cpp` | Money arithmetic and stream operators |
| `Q5/main.cpp` | Prefix/postfix increment and checked subscript operator |
| `Q6/main.cpp` | Text class, operator overloading and Rule of Three |
| `Q7/main.cpp` | Complex-number arithmetic and electrical impedance |
| `Assignment_3_CO3_Answers.docx` | Full written assignment answers |
| `BUILD_VERIFICATION.md` | Build status and program outputs |

## Requirements

Install a C++17 compiler. GCC (`g++`) is recommended. On Windows, install MinGW-w64 or MSYS2 and ensure `g++` is available in the terminal PATH.

## Compile and run

Run commands from the project root.

### Windows PowerShell (MinGW)

```powershell
g++ -std=c++17 -Wall -Wextra -pedantic Q1/main.cpp -o Q1/program.exe
.\Q1\program.exe
```

Repeat with `Q2` through `Q7`.

### Linux / macOS

```bash
g++ -std=c++17 -Wall -Wextra -pedantic Q1/main.cpp -o Q1/program
./Q1/program
```

Repeat with `Q2` through `Q7`.

## Memory checks

For Q2, Q3 and Q6, try AddressSanitizer if your compiler supports it:

```bash
g++ -std=c++17 -g -fsanitize=address -fno-omit-frame-pointer Q2/main.cpp -o Q2/asan
./Q2/asan
```

Repeat for Q3 and Q6.

## Submission checklist

1. Add your name, register number, college and faculty details where required.
2. Compile and run each program on your own computer.
3. Capture genuine screenshots of the terminal output.
4. Add the required GitHub repository URL.
5. Record any requested execution timings on your own machine, including compiler and optimization settings.
6. Read and understand each program so you can explain the implementation during viva or verification.

## Implementation notes

- Q2 includes `<stdexcept>` for its exception type.
- Q3 disables copying because its raw dynamically allocated seat map has unique ownership; default copying would risk double deletion.
- Q4 adds Money values directly in the internal `long long` paise representation.
- Q5 and Q6 include `<utility>` for `std::move`.

The output files are program run results from the build environment, not screenshots or machine-specific timing evidence.
