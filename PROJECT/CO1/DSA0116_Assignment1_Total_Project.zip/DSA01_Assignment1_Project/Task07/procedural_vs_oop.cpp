#include <iostream>
constexpr long long MIN_BALANCE = 5000;
long long proceduralBalance = 10000;
bool proceduralCanTravel(long long fare) {
    return fare >= 0 && proceduralBalance - fare >= MIN_BALANCE;
}
bool proceduralDeduct(long long fare) {
    if (!proceduralCanTravel(fare)) return false;
    proceduralBalance -= fare;
    return true;
}
class SmartCard {
    long long balance_;
public:
    explicit SmartCard(long long b) : balance_(b) {}
    bool canTravel(long long fare) const {
        return fare >= 0 && balance_ - fare >= MIN_BALANCE;
    }
    bool deduct(long long fare) {
        if (!canTravel(fare)) return false;
        balance_ -= fare;
        return true;
    }
    long long balance() const { return balance_; }
};
int main() {
    std::cout << "Procedural accepted: " << proceduralDeduct(3000)
              << ", balance paise: " << proceduralBalance << '\n';
    SmartCard card(10000);
    std::cout << "OOP accepted: " << card.deduct(3000)
              << ", balance paise: " << card.balance() << '\n';
}
