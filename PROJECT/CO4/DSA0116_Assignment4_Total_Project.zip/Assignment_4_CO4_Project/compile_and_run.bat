@echo off
setlocal
if "%~1"=="" (
  echo Usage: compile_and_run.bat task1^|task2^|task3^|task4^|task5^|task6
  exit /b 1
)
set "SRC="
if /I "%~1"=="task1" set "SRC=src\task1_staff_hierarchy.cpp"
if /I "%~1"=="task2" set "SRC=src\task2_constructor_order.cpp"
if /I "%~1"=="task3" set "SRC=src\task3_student_composition.cpp"
if /I "%~1"=="task4" set "SRC=src\task4_virtual_destructor.cpp"
if /I "%~1"=="task5" set "SRC=src\task5_cart_this_pointer.cpp"
if /I "%~1"=="task6" set "SRC=src\task6_vehicle_rental.cpp"
if "%SRC%"=="" (
  echo Invalid task. Choose task1 through task6.
  exit /b 1
)
g++ -std=c++17 -Wall -Wextra -pedantic "%SRC%" -o "%~1.exe"
if errorlevel 1 exit /b 1
"%~1.exe"
