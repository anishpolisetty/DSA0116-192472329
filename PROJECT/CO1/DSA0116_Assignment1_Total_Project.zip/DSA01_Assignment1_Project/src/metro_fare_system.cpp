#include <iostream>
#include <iomanip>
#include <array>
#include <string>
#include <sstream>
#include <limits>

using namespace std;

enum class Zone { Inner = 0, Middle = 1, Outer = 2, Airport = 3 };
enum class PassengerType { Regular, Student, Senior };

constexpr array<long long, 4> BASE_FARE_PAISE = {1000, 2000, 3000, 6000};
constexpr long long MIN_BALANCE_PAISE = 5000;
constexpr int CONCESSION_PERCENT = 50;
constexpr int PEAK_SURCHARGE_PERCENT = 20;
constexpr int WEEKEND_DISCOUNT_PERCENT = 10;

bool isPeak(int hour, int minute) {
    if (hour < 0 || hour > 23 || minute < 0 || minute > 59) return false;
    return (hour >= 8 && hour < 10) || (hour >= 17 && hour < 20);
}

bool validTime(int hour, int minute) {
    return hour >= 0 && hour <= 23 && minute >= 0 && minute <= 59;
}

long long calculateFare(Zone zone, PassengerType passenger, int hour,
                        int minute, bool weekend) {
    int index = static_cast<int>(zone);
    if (index < 0 || index >= static_cast<int>(BASE_FARE_PAISE.size())) return -1;

    long long amount = BASE_FARE_PAISE[index];

    // Assumption: concession is applied to base fare first.
    if (passenger != PassengerType::Regular)
        amount = (amount * CONCESSION_PERCENT + 50) / 100;

    // Weekend discount replaces, and does not combine with, peak surcharge.
    if (weekend) {
        amount = (amount * (100 - WEEKEND_DISCOUNT_PERCENT) + 50) / 100;
    } else if (isPeak(hour, minute)) {
        amount = (amount * (100 + PEAK_SURCHARGE_PERCENT) + 50) / 100;
    }
    return amount;
}

string money(long long paise) {
    return "Rs " + to_string(paise / 100) + "." +
           (paise % 100 < 10 ? "0" : "") + to_string(paise % 100);
}

class SmartCard {
private:
    long long balancePaise;

public:
    explicit SmartCard(long long initialBalance) : balancePaise(initialBalance) {}

    long long balance() const { return balancePaise; }

    bool canTravel(long long farePaise) const {
        return farePaise >= 0 && balancePaise - farePaise >= MIN_BALANCE_PAISE;
    }

    bool deduct(long long farePaise) {
        if (!canTravel(farePaise)) return false;
        balancePaise -= farePaise;
        return true;
    }

    bool recharge(long long amountPaise) {
        if (amountPaise <= 0) return false;
        balancePaise += amountPaise;
        return true;
    }
};

class MonthlyPass {
private:
    array<bool, 4> coveredZones{false, false, false, false};

public:
    MonthlyPass(Zone first, Zone second) {
        coveredZones[static_cast<int>(first)] = true;
        coveredZones[static_cast<int>(second)] = true;
    }

    bool covers(Zone zone) const {
        int index = static_cast<int>(zone);
        return index >= 0 && index < 4 && coveredZones[index];
    }
};

int main() {
    SmartCard card(10000); // Rs 100.00
    cout << "NAMMA METRO SMART-CARD FARE SYSTEM\n";
    cout << "Initial balance: " << money(card.balance()) << "\n\n";

    struct Trip {
        Zone zone;
        PassengerType passenger;
        int hour;
        int minute;
        bool weekend;
    };

    const array<Trip, 5> trips{{
        {Zone::Inner, PassengerType::Regular, 7, 30, false},
        {Zone::Middle, PassengerType::Student, 8, 0, false},
        {Zone::Outer, PassengerType::Senior, 10, 0, false},
        {Zone::Airport, PassengerType::Regular, 18, 0, true},
        {Zone::Outer, PassengerType::Regular, 20, 0, false}
    }};

    for (size_t i = 0; i < trips.size(); ++i) {
        const auto& t = trips[i];
        if (!validTime(t.hour, t.minute)) {
            cout << "Trip " << i + 1 << ": Invalid time\n";
            continue;
        }

        long long fare = calculateFare(t.zone, t.passenger, t.hour,
                                       t.minute, t.weekend);
        cout << "Trip " << i + 1 << ": ";
        if (card.deduct(fare)) {
            cout << "Fare " << money(fare)
                 << " | Remaining balance " << money(card.balance()) << "\n";
        } else {
            cout << "Denied (minimum balance of Rs 50 must remain) | Balance "
                 << money(card.balance()) << "\n";
        }
    }

    MonthlyPass pass(Zone::Inner, Zone::Middle);
    cout << "\nMonthly pass covers Inner: "
         << (pass.covers(Zone::Inner) ? "Yes" : "No") << "\n";
    cout << "Monthly pass covers Airport: "
         << (pass.covers(Zone::Airport) ? "Yes" : "No") << "\n";

    return 0;
}
