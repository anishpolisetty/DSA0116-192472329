int& danglingReference() {
    int local = 50;
    return local; // Intentionally unsafe: compile only to observe the diagnostic.
}
int main() {
    // Do not call danglingReference(): using the returned reference is undefined behaviour.
}
