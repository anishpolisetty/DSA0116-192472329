#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include <utility>

class Staff {
private:
    std::string name_;
    int id_;
    double basic_;
protected:
    static constexpr double DA_RATE = 0.42;
    double basic() const { return basic_; }
public:
    Staff(std::string n, int id, double b)
        : name_(std::move(n)), id_(id), basic_(b) {}
    virtual ~Staff() = default;
    virtual double pay() const = 0;
    virtual void display() const {
        std::cout << id_ << " " << name_ << " Pay: " << pay() << '\n';
    }
};
class Professor : public Staff {
    double research_;
public:
    Professor(std::string n,int id,double b,double r)
        : Staff(std::move(n),id,b), research_(r) {}
    double pay() const override { return basic()+basic()*DA_RATE+research_; }
};
class LabAssistant : public Staff {
public:
    LabAssistant(std::string n,int id,double b):Staff(std::move(n),id,b){}
    double pay() const override { return basic()+basic()*DA_RATE; }
};
class GuestFaculty : public Staff {
    double hours_, rate_;
public:
    GuestFaculty(std::string n,int id,double h,double r)
        :Staff(std::move(n),id,0),hours_(h),rate_(r){}
    double pay() const override { return hours_*rate_; }
};
int main() {
    std::vector<std::unique_ptr<Staff>> people;
    people.push_back(std::make_unique<Professor>("Asha",101,50000,8000));
    people.push_back(std::make_unique<LabAssistant>("Ravi",102,30000));
    people.push_back(std::make_unique<GuestFaculty>("Meera",103,20,1200));
    for (const auto& s : people) s->display();
}
