# Task04

Implements SavingsAccount with private data and a 10-element transaction array. Once full, it shifts left and discards the oldest transaction.

Compile: `g++ -std=c++17 -Wall -Wextra main.cpp -o program`

Run the executable and compare its output with `sample_output.txt`.
