@echo off
if not exist build mkdir build
call :run Task01\bill_hierarchy.cpp task01 || exit /b 1
call :run Task02\runtime_binding.cpp task02 || exit /b 1
call :run Task03\payer_extension.cpp task03 || exit /b 1
call :run Task04\exception_hierarchy.cpp task04 || exit /b 1
call :run Task05\stack_unwinding.cpp task05 || exit /b 1
call :run Task06\complete_bill_todo.cpp task06 || exit /b 1
call :run Task07\claim_rethrow_todo.cpp task07_claim || exit /b 1
call :run Task07\error_conditions.cpp task07_errors || exit /b 1
call :run Task09\extension_test.cpp task09 || exit /b 1
echo Safe examples compiled and executed. Run Task08 benchmarks separately.
exit /b 0
:run
echo ===== %2 =====
g++ -std=c++17 -Wall -Wextra -pedantic %1 -o build\%2.exe
if errorlevel 1 exit /b 1
build\%2.exe
exit /b 0
