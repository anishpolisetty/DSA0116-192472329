#include <iomanip>
#include <iostream>
 
class Money {
    long long paise_;
 
public:
    Money(long long rupees = 0, int p = 0)
        : paise_(rupees * 100 + p) {}
 
    Money operator+(const Money& other) const {
        Money result;
        result.paise_ = paise_ + other.paise_;
        return result;
    }
 
    Money operator-(const Money& other) const {
        Money result;
        result.paise_ = paise_ - other.paise_;
        return result;
    }
 
    Money& operator+=(const Money& other) {
        paise_ += other.paise_;
        return *this;
    }
 
    bool operator==(const Money& other) const {
        return paise_ == other.paise_;
    }
 
    bool operator<(const Money& other) const {
        return paise_ < other.paise_;
    }
 
    friend std::ostream& operator<<(std::ostream& out, const Money& m) {
        long long absValue = m.paise_ < 0 ? -m.paise_ : m.paise_;
        if (m.paise_ < 0) out << "-";
        out << "Rs " << absValue / 100 << '.'
            << std::setw(2) << std::setfill('0') << absValue % 100
            << std::setfill(' ');
        return out;
    }
 
    friend std::istream& operator>>(std::istream& in, Money& m) {
        long long rupees;
        int paise;
        if (in >> rupees >> paise) m.paise_ = rupees * 100 + paise;
        return in;
    }
};
 
int main() {
    Money a(120, 75), b(79, 25);
    Money c = a + b;
    std::cout << c << '\n' << std::boolalpha << (c == Money(200)) << '\n';
 
    Money x(0, 75), y(0, 50);
    std::cout << (x + y) << '\n';
}
