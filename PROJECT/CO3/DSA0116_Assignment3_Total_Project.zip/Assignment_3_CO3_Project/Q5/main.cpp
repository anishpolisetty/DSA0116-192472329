#include <iostream>
#include <utility>
#include <stdexcept>
#include <string>
#include <vector>
 
class Time {
    int seconds_ = 0; // seconds since 00:00:00
public:
    explicit Time(int s = 0) : seconds_(s) {
        if (s < 0) throw std::invalid_argument("Negative time");
    }
    Time& operator++() { ++seconds_; return *this; }       // prefix
    Time operator++(int) { Time old(*this); ++seconds_; return old; } // postfix
    bool operator==(const Time& rhs) const { return seconds_ == rhs.seconds_; }
    bool operator<(const Time& rhs) const { return seconds_ < rhs.seconds_; }
    void print() const {
        int h = seconds_ / 3600;
        int m = (seconds_ / 60) % 60;
        int s = seconds_ % 60;
        std::cout << h << ':' << (m < 10 ? "0" : "") << m
                  << ':' << (s < 10 ? "0" : "") << s;
    }
};
 
class Playlist {
    std::vector<std::string> tracks_;
public:
    explicit Playlist(std::vector<std::string> tracks)
        : tracks_(std::move(tracks)) {}
 
    std::string& operator[](int i) {
        if (i < 0 || i >= static_cast<int>(tracks_.size()))
            throw std::out_of_range("Playlist index out of range");
        return tracks_[static_cast<std::size_t>(i)];
    }
 
    const std::string& operator[](int i) const {
        if (i < 0 || i >= static_cast<int>(tracks_.size()))
            throw std::out_of_range("Playlist index out of range");
        return tracks_[static_cast<std::size_t>(i)];
    }
 
    std::size_t size() const { return tracks_.size(); }
};
 
int main() {
    Time t(10);
    Time a = t++;
    Time b = ++t;
    a.print(); std::cout << ' ';
    b.print(); std::cout << ' ';
    t.print(); std::cout << '\n';
 
    Playlist p({"Track One", "Track Two"});
    std::cout << p[0] << '\n';
    try { std::cout << p[2] << '\n'; }
    catch (const std::out_of_range& e) { std::cout << e.what() << '\n'; }
}
