#include <algorithm>
#include <iomanip>
#include <iostream>
#include <map>
#include <memory>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

class Bill {
protected:
    std::string id, patient;
public:
    Bill(std::string i, std::string p) : id(std::move(i)), patient(std::move(p)) {}
    virtual ~Bill() = default;
    virtual double total() const = 0;
    virtual std::string type() const = 0;
    void print() const {
        std::cout << type() << " | " << id << " | " << patient << " | "
                  << std::fixed << std::setprecision(2) << total() << '\n';
    }
};
class OutPatientBill : public Bill {
    double consultation, tests;
public:
    OutPatientBill(std::string i, std::string p, double c, double t)
        : Bill(std::move(i), std::move(p)), consultation(c), tests(t) {
        if (c < 0 || t < 0) throw std::invalid_argument("negative OP charge");
    }
    double total() const override { return consultation + tests; }
    std::string type() const override { return "OP"; }
};
class InPatientBill : public Bill {
    int days; double roomRate, procedure, medicines;
public:
    InPatientBill(std::string i, std::string p, int d, double r, double proc, double med)
        : Bill(std::move(i), std::move(p)), days(d), roomRate(r), procedure(proc), medicines(med) {
        if (d < 0 || r < 0 || proc < 0 || med < 0)
            throw std::invalid_argument("negative IP charge or days");
    }
    double total() const override { return days * roomRate + procedure + medicines; }
    std::string type() const override { return "IP"; }
};
class DayCareBill : public Bill {
    double packagePrice;
public:
    DayCareBill(std::string i, std::string p, double price)
        : Bill(std::move(i), std::move(p)), packagePrice(price) {
        if (price < 0) throw std::invalid_argument("negative package price");
    }
    double total() const override { return packagePrice; }
    std::string type() const override { return "DAYCARE"; }
};
class EmergencyBill : public Bill {
    double base, rate; int units;
public:
    EmergencyBill(std::string i, std::string p, double b, double r, int u)
        : Bill(std::move(i), std::move(p)), base(b), rate(r), units(u) {
        if (b < 0 || r < 0 || u < 0) throw std::invalid_argument("negative emergency charge");
    }
    double total() const override { return base + rate * units; }
    std::string type() const override { return "EMERGENCY"; }
};
class Payer {
public:
    virtual ~Payer() = default;
    virtual double amountCovered(const Bill&) const = 0;
};
class SelfPay : public Payer {
public: double amountCovered(const Bill& b) const override { return b.total(); }
};
class Insurance : public Payer {
    double limit, copay;
public:
    Insurance(double l, double c) : limit(l), copay(c) {
        if (l < 0 || c < 0 || c > 100) throw std::invalid_argument("invalid policy");
    }
    double amountCovered(const Bill& b) const override {
        return std::min(b.total(), limit) * (1.0 - copay / 100.0);
    }
};
class GovernmentScheme : public Payer {
    std::map<std::string,double> caps;
public:
    explicit GovernmentScheme(std::map<std::string,double> x) : caps(std::move(x)) {}
    double amountCovered(const Bill& b) const override {
        auto it = caps.find(b.type());
        if (it == caps.end()) throw std::runtime_error("unknown package");
        return std::min(b.total(), it->second);
    }
};
int main() {
    std::vector<std::unique_ptr<Bill>> bills;
    bills.push_back(std::make_unique<OutPatientBill>("B001","Ravi",500,1200));
    bills.push_back(std::make_unique<InPatientBill>("B002","Meena",3,2500,40000,0));
    bills.push_back(std::make_unique<DayCareBill>("B003","Arun",30000));
    bills.push_back(std::make_unique<EmergencyBill>("B004","Sara",2000,500,10));
    SelfPay self; Insurance insurance(50000,20);
    GovernmentScheme govt({{"OP",1500},{"IP",40000},{"DAYCARE",25000},{"EMERGENCY",6000}});
    double sum=0;
    for (const auto& b : bills) {
        b->print(); sum += b->total();
        std::cout << "Self=" << self.amountCovered(*b)
                  << " Insurance=" << insurance.amountCovered(*b)
                  << " Government=" << govt.amountCovered(*b) << '\n';
    }
    std::cout << "Daily total: " << sum << '\n';
}
