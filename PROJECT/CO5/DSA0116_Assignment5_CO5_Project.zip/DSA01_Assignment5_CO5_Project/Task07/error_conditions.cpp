#include <iostream>
#include <new>
#include <stdexcept>
#include <string>
struct Resource { ~Resource() noexcept { std::cout<<"Resource released\n"; } };
void validate(double amount){
    if(amount<0)throw std::invalid_argument("negative amount");
    if(amount>1000000)throw std::out_of_range("too large");
}
int main(){
    Resource resource;
    try{
        try{validate(-5);}catch(const std::invalid_argument& e){std::cout<<"Input error: "<<e.what()<<'\n';}
        try{(void)std::stod("not-a-number");}catch(const std::invalid_argument& e){std::cout<<"Conversion error: "<<e.what()<<'\n';}
        try{throw std::bad_alloc();}catch(const std::bad_alloc&){std::cout<<"Allocation failure handled\n";}
        try{validate(2000000);}catch(const std::exception& e){std::cout<<"Top-level recoverable error: "<<e.what()<<'\n';}
    }catch(...){std::cout<<"Unknown failure handled\n";}
    std::cout<<"Program continues\n";
}
