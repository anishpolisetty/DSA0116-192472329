#include <iostream>
#include <vector>
#include <chrono>
using namespace std;
using namespace chrono;

// Original design: shift all stored values when the fixed buffer is full.
class ShiftHistory {
    vector<int> data;
    int capacity;
public:
    explicit ShiftHistory(int k) : data(k), capacity(k) {}
    void add(int value) {
        for (int i = 1; i < capacity; ++i) data[i - 1] = data[i];
        data[capacity - 1] = value;
    }
};

// Redesigned: circular index overwrites the oldest value in constant time.
class CircularHistory {
    vector<int> data;
    int nextIndex = 0;
    int capacity;
public:
    explicit CircularHistory(int k) : data(k), capacity(k) {}
    void add(int value) {
        data[nextIndex] = value;
        nextIndex = (nextIndex + 1) % capacity;
    }
};

int main() {
    const int capacity = 50;
    const int operations = 2000000;
    ShiftHistory original(capacity);
    CircularHistory redesigned(capacity);

    auto start1 = steady_clock::now();
    for (int i = 0; i < operations; ++i) original.add(i);
    auto end1 = steady_clock::now();

    auto start2 = steady_clock::now();
    for (int i = 0; i < operations; ++i) redesigned.add(i);
    auto end2 = steady_clock::now();

    cout << "Operations: " << operations << ", capacity: " << capacity << '\n';
    cout << "Shift design (ms): "
         << duration<double, milli>(end1 - start1).count() << '\n';
    cout << "Circular design (ms): "
         << duration<double, milli>(end2 - start2).count() << '\n';
    cout << "Expected insertion complexity: O(k) vs O(1)\n";
}
