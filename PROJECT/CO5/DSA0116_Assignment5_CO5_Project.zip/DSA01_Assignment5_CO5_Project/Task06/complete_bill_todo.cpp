#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include <stdexcept>
class Bill {
protected: std::string patient;
public:
    explicit Bill(const std::string& p):patient(p){}
    virtual ~Bill()=default;
    virtual double total() const=0; // TODO 1: pure virtual
    virtual std::string type() const{return "Bill";}
    void print() const{std::cout<<type()<<' '<<patient<<": "<<total()<<'\n';}
};
class OutPatient:public Bill {
    double consultation,tests;
public:
    OutPatient(const std::string& p,double c,double t):Bill(p),consultation(c),tests(t){
        if(c<0||t<0)throw std::invalid_argument("negative charge");
    }
    double total() const override{return consultation+tests;} // TODO 2
    std::string type() const override{return "OP";}
};
class InPatient:public Bill {
    int days; double perDay,surgery;
public:
    InPatient(const std::string& p,int d,double r,double s):Bill(p),days(d),perDay(r),surgery(s){
        if(d<0||r<0||s<0)throw std::invalid_argument("negative charge or days");
    }
    double total() const override{return days*perDay+surgery;} // TODO 3
    std::string type() const override{return "IP";}
};
int main(){
    std::vector<std::unique_ptr<Bill>> bills;
    bills.push_back(std::make_unique<OutPatient>("Ravi",500,1200));
    bills.push_back(std::make_unique<InPatient>("Meena",3,2500,40000));
    double sum=0;
    for(const auto& b:bills){b->print();sum+=b->total();}
    std::cout<<"Total "<<sum<<'\n';
}
