#include <iostream>
struct PersonT { PersonT(){std::cout<<"Person+ ";}
                 ~PersonT(){std::cout<<"Person- ";} };
struct StudentT : virtual PersonT {
    StudentT(){std::cout<<"Student+ ";}
    ~StudentT(){std::cout<<"Student- ";}
};
struct StaffT : virtual PersonT {
    StaffT(){std::cout<<"Staff+ ";}
    ~StaffT(){std::cout<<"Staff- ";}
};
struct TAT : StudentT, StaffT {
    TAT():PersonT(){std::cout<<"TA+ ";}
    ~TAT(){std::cout<<"TA- ";}
};
int main(){
 { StudentT s; std::cout<<"| "; }
 std::cout<<'\n';
 { StaffT s; std::cout<<"| "; }
 std::cout<<'\n';
 { TAT t; std::cout<<"| "; }
 std::cout<<'\n';
}
