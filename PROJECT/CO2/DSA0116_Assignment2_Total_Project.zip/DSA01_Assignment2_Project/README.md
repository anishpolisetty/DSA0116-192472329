# DSA01 Assignment 2 – CO2 C++ Project

## Student details
- Name: [Enter your name]
- Register number: [Enter your register number]
- GitHub repository: `DSA01-<RegisterNumber>-Assignment2`
- Compiler: g++ (version recorded in `BUILD_CHECK.txt`)
- Language standard: C++17

## Build and run
From the project root, compile any task using:
```bash
g++ -std=c++17 -Wall -Wextra Task01/main.cpp -o Task01/program
./Task01/program
```
Replace `Task01` with `Task02` ... `Task07`. On Windows, run `Task01\program.exe`.

## Task index
| Folder | Topic | Main evidence |
|---|---|---|
| Task01 | Call by value/reference/pointer; default arguments; return by reference | `sample_output.txt` |
| Task02 | Return by reference, const reference, copy; dangling reference warning | `sample_output.txt`, `dangling_warning.cpp` |
| Task03 | Default arguments and function overloading | `sample_output.txt` |
| Task04 | Class with fixed transaction array | `sample_output.txt` |
| Task05 | Static members and array of objects | `sample_output.txt` |
| Task06 | Friend and inline functions; benchmark | sample output and benchmark text files |
| Task07 | Diagnose and redesign: shifting history to circular buffer | benchmark text files |

## Important submission notes
1. Replace the student placeholders and add your working GitHub URL to the report.
2. The output text files are executions in the current build environment. Capture your own screenshots in your IDE/terminal and save them in the corresponding task folder if screenshots are required by your faculty.
3. Commit progressively: make at least one meaningful commit per task. Do not upload everything in a single final commit.
4. Review the explanations and verify you can defend the code in a viva.
5. `Task02/dangling_warning.cpp` is intentionally unsafe and is included only to demonstrate a compiler diagnostic. Do not call the function or use its returned reference.
6. Timing measurements are machine-, compiler-, and optimisation-dependent. Re-run them on your system and report your own measured values.

## Design assumptions
- Courier tariff in Task03: ₹20 per kg, express surcharge ₹50, insurance ₹15. These are illustrative rates because the assignment does not specify actual rates.
- In Task04, transactions are stored as signed amounts: positive for deposit and negative for withdrawal. The oldest item is discarded when the array is full.
- Task05 capacity is 3 as specified in the starter code. The static counter is shared by every `BusTicket` object in the process.
- Task07 uses a 50-entry history and 2,000,000 insertions for a reproducible comparison. The circular buffer stores items in circular order; a display routine would traverse from the oldest index when required.
