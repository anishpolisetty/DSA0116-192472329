# Task05

Implements a static ticket counter, capacity enforcement, an array of ticket objects, and the Token output-prediction program.

Compile: `g++ -std=c++17 -Wall -Wextra main.cpp -o program`

Run the executable and compare its output with `sample_output.txt`.
