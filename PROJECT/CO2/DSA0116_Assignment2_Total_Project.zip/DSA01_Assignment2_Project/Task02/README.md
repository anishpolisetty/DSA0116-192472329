# Task02

Returns an array element by reference so it can be modified; also demonstrates const-reference and copy alternatives. The dangling-reference function is intentionally not called.

Compile: `g++ -std=c++17 -Wall -Wextra main.cpp -o program`

Run the executable and compare its output with `sample_output.txt`.
