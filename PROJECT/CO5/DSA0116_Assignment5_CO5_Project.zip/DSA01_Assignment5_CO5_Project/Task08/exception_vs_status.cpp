#include <chrono>
#include <iostream>
#include <stdexcept>
#include <vector>
enum class Status{Ok,Invalid};
struct Result{Status status;double value;};
Result statusCheck(double x,bool bad){return bad?Result{Status::Invalid,0}:Result{Status::Ok,x};}
double exceptionCheck(double x,bool bad){if(bad)throw std::runtime_error("invalid");return x;}
int main(){
    constexpr std::size_t N=1000000;
    for(int pct:{0,1,50}){
        std::vector<unsigned char> invalid(N,0);
        for(std::size_t i=0;i<N*static_cast<std::size_t>(pct)/100;++i)invalid[i]=1;
        auto start1=std::chrono::steady_clock::now();std::size_t accepted1=0;double sum1=0;
        for(auto bad:invalid){auto r=statusCheck(100,bad!=0);if(r.status==Status::Ok){++accepted1;sum1+=r.value;}}
        auto end1=std::chrono::steady_clock::now();
        auto start2=std::chrono::steady_clock::now();std::size_t accepted2=0;double sum2=0;
        for(auto bad:invalid){try{sum2+=exceptionCheck(100,bad!=0);++accepted2;}catch(const std::exception&){}}
        auto end2=std::chrono::steady_clock::now();
        auto ms1=std::chrono::duration<double,std::milli>(end1-start1).count();
        auto ms2=std::chrono::duration<double,std::milli>(end2-start2).count();
        std::cout<<pct<<"% invalid | status ms="<<ms1<<" accepted="<<accepted1
                 <<" | exception ms="<<ms2<<" accepted="<<accepted2
                 <<" | checksums="<<sum1<<','<<sum2<<'\n';
    }
}
