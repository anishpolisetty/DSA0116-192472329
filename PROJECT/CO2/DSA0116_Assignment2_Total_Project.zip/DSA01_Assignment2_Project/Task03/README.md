# Task03

Uses a distinct int-grams overload, double-kilograms overload with trailing defaults, and Parcel overload. Illustrative tariff assumptions are documented in the root README.

Compile: `g++ -std=c++17 -Wall -Wextra main.cpp -o program`

Run the executable and compare its output with `sample_output.txt`.
