# Assignment 4 – CO4: Designing Reusable Class Hierarchies

This project folder contains standalone C++ source files corresponding to the main programming examples in the professional assignment answer document.

## Folder structure

```text
Assignment_4_CO4_Project/
├── README.md
├── compile_and_run.bat
└── src/
    ├── task1_staff_hierarchy.cpp
    ├── task2_constructor_order.cpp
    ├── task3_student_composition.cpp
    ├── task4_virtual_destructor.cpp
    ├── task5_cart_this_pointer.cpp
    └── task6_vehicle_rental.cpp
```

## Requirements

- C++17-compatible compiler (g++ recommended).
- Windows: MinGW-w64 / MSYS2, or use the compiler configured in your IDE.
- Linux/macOS: GCC or Clang.

## Compile and run

Open a terminal in this folder and compile one task at a time:

```bash
g++ -std=c++17 -Wall -Wextra -pedantic src/task1_staff_hierarchy.cpp -o task1
./task1
```

Replace the source filename and output name for Tasks 2–6. On Windows, run the generated `.exe` file, for example `task1.exe`.

A Windows helper script is also included. Run `compile_and_run.bat task1` (or `task2` ... `task6`) from the project folder.

## Task mapping

| Source file | Main concept |
|---|---|
| task1_staff_hierarchy.cpp | Abstract base class, inheritance, runtime polymorphism |
| task2_constructor_order.cpp | Virtual inheritance and constructor/destructor order |
| task3_student_composition.cpp | Composition and member initializer lists |
| task4_virtual_destructor.cpp | Virtual destructor and safe polymorphic deletion |
| task5_cart_this_pointer.cpp | Object pointers, references, `this`, method chaining |
| task6_vehicle_rental.cpp | Vehicle hierarchy and polymorphic rental calculations |

## Important

Each `.cpp` file is intended to be compiled independently. These files provide runnable examples, not evidence that a particular compiler run has occurred on your computer. Run them locally and capture your own output screenshots for submission if required. Review the assignment answer document for explanations, UML/design discussion, alternative designs, and written analysis.
