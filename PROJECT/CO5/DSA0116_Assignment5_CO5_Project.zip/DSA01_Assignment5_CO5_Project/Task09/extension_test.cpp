#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>
class Bill{
protected:std::string patient;
public:explicit Bill(std::string p):patient(std::move(p)){}virtual ~Bill()=default;
    virtual double total()const=0;virtual std::string type()const=0;
};
class OutPatient:public Bill{
    double c,t;
public:OutPatient(std::string p,double x,double y):Bill(std::move(p)),c(x),t(y){}
    double total()const override{return c+t;}std::string type()const override{return "OP";}
};
class MaternityBill:public Bill{ // new bill type
    double package,tests;
public:
    MaternityBill(std::string p,double pkg,double t):Bill(std::move(p)),package(pkg),tests(t){
        if(pkg<0||t<0)throw std::invalid_argument("negative maternity charge");
    }
    double total()const override{return package+tests;}
    std::string type()const override{return "MATERNITY";}
};
class Payer{public:virtual ~Payer()=default;virtual double amountCovered(const Bill&)const=0;};
class SelfPay:public Payer{public:double amountCovered(const Bill& b)const override{return b.total();}};
class CorporatePayer:public Payer{ // new payer
    double fraction;
public:
    explicit CorporatePayer(double f):fraction(f){if(f<0||f>1)throw std::invalid_argument("fraction must be 0..1");}
    double amountCovered(const Bill& b)const override{return b.total()*fraction;}
};
int main(){
    std::vector<std::unique_ptr<Bill>> bills;
    bills.push_back(std::make_unique<OutPatient>("Ravi",500,1200));
    bills.push_back(std::make_unique<MaternityBill>("Anu",45000,5000));
    SelfPay self;CorporatePayer corporate(0.8);
    for(const auto& b:bills)
        std::cout<<b->type()<<" total="<<b->total()
                 <<" self="<<self.amountCovered(*b)
                 <<" corporate="<<corporate.amountCovered(*b)<<'\n';
}
